"""
Google Colab notebook utilities.
"""
